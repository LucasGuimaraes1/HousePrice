﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HousePricePrediction
{
    static class TestTrips
    {
        internal static readonly HousePrice Trip1 = new HousePrice
        {
            id = 7129300520,
            price = 221900,
            bedrooms = 3,
            bathrooms = 1,
            sqft_lot = 5650,
            floors = 1
        };
    }
}